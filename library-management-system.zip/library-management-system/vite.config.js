import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { viteSingleFile } from 'vite-plugin-singlefile';

// base './' + single-file output lets the built app run by double-clicking index.html
export default defineConfig({
  base: './',
  plugins: [react(), viteSingleFile()],
});
