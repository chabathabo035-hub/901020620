import { Routes, Route, Navigate } from 'react-router-dom';
import Navbar from './components/Navbar.jsx';
import RequireRole from './components/RequireRole.jsx';
import Dashboard from './pages/Dashboard.jsx';
import BooksPage from './pages/BooksPage.jsx';
import TransactionsPage from './pages/TransactionsPage.jsx';
import UsersPage from './pages/UsersPage.jsx';

export default function App() {
  return (
    <div className="app">
      <a className="skip-link" href="#main">Skip to content</a>
      <Navbar />
      <main id="main" className="container">
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route
            path="/books"
            element={
              <RequireRole roles={['admin', 'librarian']}>
                <BooksPage />
              </RequireRole>
            }
          />
          <Route
            path="/transactions"
            element={
              <RequireRole roles={['admin', 'librarian']}>
                <TransactionsPage />
              </RequireRole>
            }
          />
          <Route path="/users" element={<UsersPage />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
      <footer className="footer">
        Library Management System · React + local storage · data is saved in this browser only
      </footer>
    </div>
  );
}
