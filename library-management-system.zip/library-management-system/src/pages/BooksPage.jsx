import { useMemo, useState } from 'react';
import { useLibrary } from '../context/LibraryContext.jsx';
import BookForm from '../components/BookForm.jsx';
import BookList from '../components/BookList.jsx';

export default function BooksPage() {
  const { books, addBook, updateBook, deleteBook } = useLibrary();
  const [editing, setEditing] = useState(null);
  const [query, setQuery] = useState('');
  const [notice, setNotice] = useState('');

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    return books.filter((b) => !q || [b.title, b.author, b.genre, b.isbn].some((f) => f.toLowerCase().includes(q)));
  }, [books, query]);

  const handleEdit = (book) => {
    setEditing(book);
    setNotice('');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDelete = (book) => {
    if (!window.confirm(`Delete “${book.title}” from the catalogue? This cannot be undone.`)) return;
    deleteBook(book.id);
    if (editing && editing.id === book.id) setEditing(null);
    setNotice(`“${book.title}” was deleted.`);
  };

  return (
    <>
      <h1>Book management</h1>
      <BookForm
        initial={editing}
        onSubmit={(values) => (editing ? updateBook(editing.id, values) : addBook(values))}
        onCancel={() => setEditing(null)}
      />

      <section className="card">
        <h2>Catalogue ({books.length})</h2>
        {notice && <p className="success-text" role="status">{notice}</p>}
        <div className="toolbar">
          <input
            type="search"
            placeholder="Search catalogue…"
            aria-label="Search catalogue"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </div>
        <BookList books={visible} onEdit={handleEdit} onDelete={handleDelete} emptyText="No books in the catalogue yet." />
      </section>
    </>
  );
}
