import { useMemo, useState } from 'react';
import { useLibrary } from '../context/LibraryContext.jsx';
import TransactionForm from '../components/TransactionForm.jsx';

const fmt = (iso) =>
  new Date(iso).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' });

export default function TransactionsPage() {
  const { books, transactions, changeStock } = useLibrary();
  const [filter, setFilter] = useState('all');

  const rows = useMemo(
    () => (filter === 'all' ? transactions : transactions.filter((t) => t.type === filter)),
    [transactions, filter]
  );

  return (
    <>
      <h1>Transactions</h1>
      <TransactionForm books={books} onSubmit={changeStock} />

      <section className="card">
        <div className="toolbar between">
          <h2>History ({rows.length})</h2>
          <select aria-label="Filter history" value={filter} onChange={(e) => setFilter(e.target.value)}>
            <option value="all">All transactions</option>
            <option value="add">Stock additions</option>
            <option value="deduct">Stock deductions</option>
          </select>
        </div>

        {rows.length === 0 ? (
          <p className="empty">No transactions recorded yet.</p>
        ) : (
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Date</th>
                  <th>Book</th>
                  <th>Type</th>
                  <th className="num">Qty</th>
                  <th className="num">Stock after</th>
                  <th>By</th>
                  <th>Note</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((t) => (
                  <tr key={t.id}>
                    <td data-label="Date">{fmt(t.date)}</td>
                    <td data-label="Book"><strong>{t.bookTitle}</strong></td>
                    <td data-label="Type">
                      <span className={`badge ${t.type === 'add' ? 'badge-ok' : 'badge-warn'}`}>
                        {t.type === 'add' ? 'Addition' : 'Deduction'}
                      </span>
                    </td>
                    <td data-label="Qty" className="num">{t.type === 'add' ? '+' : '−'}{t.quantity}</td>
                    <td data-label="Stock after" className="num">{t.balanceAfter}</td>
                    <td data-label="By">{t.performedBy || '—'}</td>
                    <td data-label="Note">{t.note || '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </>
  );
}
