import { useState } from 'react';
import { useLibrary } from '../context/LibraryContext.jsx';
import LoginForm from '../components/LoginForm.jsx';
import UserForm from '../components/UserForm.jsx';

export default function UsersPage() {
  const { users, currentUser, login, addUser, updateUser, deleteUser, resetDemoData } = useLibrary();
  const [editing, setEditing] = useState(null);
  const [notice, setNotice] = useState({ type: '', text: '' });

  if (!currentUser) {
    return (
      <div className="center-narrow">
        <LoginForm onLogin={login} />
      </div>
    );
  }

  const isAdmin = currentUser.role === 'admin';

  const handleDelete = (user) => {
    if (!window.confirm(`Delete user “${user.name}”?`)) return;
    const result = deleteUser(user.id);
    setNotice(result.ok ? { type: 'ok', text: `${user.name} was deleted.` } : { type: 'err', text: result.error });
    if (result.ok && editing && editing.id === user.id) setEditing(null);
  };

  const handleReset = () => {
    if (window.confirm('Reset all books, users and transactions to the demo data? You will be logged out.')) {
      resetDemoData();
    }
  };

  return (
    <>
      <h1>User management</h1>
      <section className="card">
        <p>
          Signed in as <strong>{currentUser.name}</strong> (<span className={`badge role-${currentUser.role}`}>{currentUser.role}</span>),
          membership ID <span className="mono">{currentUser.membershipId}</span>.
        </p>
        {!isAdmin && <p className="muted">Only administrators can add, edit or delete users.</p>}
      </section>

      {isAdmin && (
        <UserForm
          initial={editing}
          onSubmit={(values) => (editing ? updateUser(editing.id, values) : addUser(values))}
          onCancel={() => setEditing(null)}
        />
      )}

      <section className="card">
        <h2>Users ({users.length})</h2>
        {notice.text && (
          <p className={notice.type === 'ok' ? 'success-text' : 'error-text'} role={notice.type === 'ok' ? 'status' : 'alert'}>
            {notice.text}
          </p>
        )}
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Name</th>
                <th>Membership ID</th>
                <th>Role</th>
                {isAdmin && <th>Actions</th>}
              </tr>
            </thead>
            <tbody>
              {users.map((u) => (
                <tr key={u.id}>
                  <td data-label="Name"><strong>{u.name}</strong>{u.id === currentUser.id && <span className="muted small"> (you)</span>}</td>
                  <td data-label="Membership ID" className="mono">{u.membershipId}</td>
                  <td data-label="Role"><span className={`badge role-${u.role}`}>{u.role}</span></td>
                  {isAdmin && (
                    <td data-label="Actions" className="actions">
                      <button className="btn btn-sm" onClick={() => { setEditing(u); setNotice({ type: '', text: '' }); window.scrollTo({ top: 0, behavior: 'smooth' }); }} aria-label={`Edit ${u.name}`}>Edit</button>
                      <button className="btn btn-sm btn-danger" onClick={() => handleDelete(u)} aria-label={`Delete ${u.name}`}>Delete</button>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {isAdmin && (
        <section className="card">
          <h2>Demo data</h2>
          <p className="muted">Restore the sample books, users and an empty transaction history.</p>
          <button className="btn btn-danger" onClick={handleReset}>Reset demo data</button>
        </section>
      )}
    </>
  );
}
