import { useMemo, useState } from 'react';
import { useLibrary } from '../context/LibraryContext.jsx';
import BookList from '../components/BookList.jsx';
import { isLowStock } from '../utils/validation.js';

export default function Dashboard() {
  const { books } = useLibrary();
  const [query, setQuery] = useState('');
  const [lowOnly, setLowOnly] = useState(false);

  const stats = useMemo(
    () => ({
      titles: books.length,
      copies: books.reduce((sum, b) => sum + b.quantity, 0),
      low: books.filter((b) => isLowStock(b)).length,
    }),
    [books]
  );

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    return books
      .filter((b) => (lowOnly ? isLowStock(b) : true))
      .filter((b) => !q || [b.title, b.author, b.genre, b.isbn].some((f) => f.toLowerCase().includes(q)));
  }, [books, query, lowOnly]);

  return (
    <>
      <h1>Dashboard</h1>
      <p className="muted">Quick overview of current book availability. Books with fewer than two copies are highlighted.</p>

      <section className="stats" aria-label="Library statistics">
        <div className="stat"><span className="stat-value">{stats.titles}</span><span className="stat-label">Book titles</span></div>
        <div className="stat"><span className="stat-value">{stats.copies}</span><span className="stat-label">Copies available</span></div>
        <div className={`stat${stats.low ? ' stat-warn' : ''}`}><span className="stat-value">{stats.low}</span><span className="stat-label">Low stock</span></div>
      </section>

      <section className="card">
        <div className="toolbar">
          <input
            type="search"
            placeholder="Search title, author, genre or ISBN…"
            aria-label="Search books"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
          <label className="inline-check">
            <input type="checkbox" checked={lowOnly} onChange={(e) => setLowOnly(e.target.checked)} />
            Low stock only
          </label>
        </div>
        <BookList books={visible} emptyText="No books match your search." />
      </section>
    </>
  );
}
