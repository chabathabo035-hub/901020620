export const seedBooks = [
  { id: 'b1', title: 'Things Fall Apart', author: 'Chinua Achebe', genre: 'Fiction', isbn: '9780385474542', quantity: 5 },
  { id: 'b2', title: 'Clean Code', author: 'Robert C. Martin', genre: 'Technology', isbn: '9780132350884', quantity: 1 },
  { id: 'b3', title: 'A Brief History of Time', author: 'Stephen Hawking', genre: 'Science', isbn: '9780553380163', quantity: 3 },
  { id: 'b4', title: 'Long Walk to Freedom', author: 'Nelson Mandela', genre: 'Biography', isbn: '9780316548182', quantity: 0 },
  { id: 'b5', title: 'Learning React', author: 'Alex Banks and Eve Porcello', genre: 'Technology', isbn: '9781492051725', quantity: 4 },
];

export const seedUsers = [
  { id: 'u1', name: 'Admin User', membershipId: 'M-0001', role: 'admin' },
  { id: 'u2', name: 'Lerato Librarian', membershipId: 'M-0002', role: 'librarian' },
  { id: 'u3', name: 'Thabo Member', membershipId: 'M-0003', role: 'member' },
];

export const seedTransactions = [];
