// Pure helper functions (no React) so they can be unit tested.

export const LOW_STOCK_THRESHOLD = 2; // "fewer than two copies" per the notes
export const ROLES = ['admin', 'librarian', 'member'];

export function normaliseIsbn(isbn) {
  return String(isbn || '').replace(/[\s-]/g, '').toUpperCase();
}

export function isValidIsbn(isbn) {
  const clean = normaliseIsbn(isbn);
  return /^\d{13}$/.test(clean) || /^\d{9}[\dX]$/.test(clean);
}

export function isWholeNumber(value) {
  return /^\d+$/.test(String(value).trim());
}

/** Validate book form values. `existing` is the current book list, `editingId` the book being edited (if any). */
export function validateBook(values, existing = [], editingId = null) {
  const errors = {};
  if (!values.title.trim()) errors.title = 'Title is required.';
  if (!values.author.trim()) errors.author = 'Author is required.';
  if (!values.genre.trim()) errors.genre = 'Genre is required.';

  if (!values.isbn.trim()) {
    errors.isbn = 'ISBN is required.';
  } else if (!isValidIsbn(values.isbn)) {
    errors.isbn = 'ISBN must be 10 or 13 digits (hyphens allowed).';
  } else {
    const clash = existing.some(
      (b) => b.id !== editingId && normaliseIsbn(b.isbn) === normaliseIsbn(values.isbn)
    );
    if (clash) errors.isbn = 'Another book already uses this ISBN.';
  }

  if (String(values.quantity).trim() === '') {
    errors.quantity = 'Quantity is required.';
  } else if (!isWholeNumber(values.quantity)) {
    errors.quantity = 'Quantity must be a whole number (0 or more).';
  }
  return errors;
}

/** Validate user form values. */
export function validateUser(values, existing = [], editingId = null) {
  const errors = {};
  if (!values.name.trim()) errors.name = 'Name is required.';
  const mid = values.membershipId.trim();
  if (!mid) {
    errors.membershipId = 'Membership ID is required.';
  } else if (existing.some((u) => u.id !== editingId && u.membershipId.toLowerCase() === mid.toLowerCase())) {
    errors.membershipId = 'This membership ID is already in use.';
  }
  if (!ROLES.includes(values.role)) errors.role = 'Choose a valid role.';
  return errors;
}

/** Validate a stock transaction against the selected book. */
export function validateStockChange(book, type, quantity) {
  const errors = {};
  if (!book) {
    errors.bookId = 'Select a book.';
    return errors;
  }
  if (!isWholeNumber(quantity) || Number(quantity) < 1) {
    errors.quantity = 'Quantity must be a whole number of at least 1.';
  } else if (type === 'deduct' && Number(quantity) > book.quantity) {
    errors.quantity =
      book.quantity === 0
        ? 'No copies are available to borrow.'
        : `Only ${book.quantity} cop${book.quantity === 1 ? 'y is' : 'ies are'} available.`;
  }
  return errors;
}

export const isLowStock = (book) => book.quantity < LOW_STOCK_THRESHOLD;
