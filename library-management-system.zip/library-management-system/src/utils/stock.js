import { validateStockChange } from './validation.js';

/**
 * Pure stock-change logic: validates, then returns the updated books and
 * transactions so the book quantity and the history entry always change together.
 */
export function applyStockChange(books, transactions, { bookId, type, quantity, note = '', performedBy = '' }, now = new Date()) {
  const book = books.find((b) => b.id === bookId);
  const errors = validateStockChange(book, type, quantity);
  if (Object.keys(errors).length) return { ok: false, errors, books, transactions };

  const qty = Number(quantity);
  const delta = type === 'add' ? qty : -qty;

  const newBooks = books.map((b) => (b.id === bookId ? { ...b, quantity: b.quantity + delta } : b));
  const entry = {
    id: `t${now.getTime()}${Math.random().toString(36).slice(2, 6)}`,
    bookId,
    bookTitle: book.title, // snapshot so history survives book deletion
    isbn: book.isbn,
    type, // 'add' | 'deduct'
    quantity: qty,
    balanceAfter: book.quantity + delta,
    note: note.trim(),
    performedBy,
    date: now.toISOString(),
  };
  return { ok: true, errors: {}, books: newBooks, transactions: [entry, ...transactions] };
}
