import { useState, useEffect } from 'react';

/**
 * useState that is initialised from local storage (JSON) and written back
 * by useEffect whenever the value changes.
 */
export function useLocalStorage(key, initialValue) {
  const [value, setValue] = useState(() => {
    try {
      const raw = window.localStorage.getItem(key);
      return raw !== null ? JSON.parse(raw) : initialValue;
    } catch {
      return initialValue;
    }
  });

  useEffect(() => {
    try {
      window.localStorage.setItem(key, JSON.stringify(value));
    } catch {
      /* storage full or unavailable: the app keeps working in memory */
    }
  }, [key, value]);

  return [value, setValue];
}
