import { createContext, useContext, useMemo } from 'react';
import { useLocalStorage } from '../utils/useLocalStorage.js';
import { seedBooks, seedUsers, seedTransactions } from '../utils/seed.js';
import { validateBook, validateUser, normaliseIsbn } from '../utils/validation.js';
import { applyStockChange } from '../utils/stock.js';

const LibraryContext = createContext(null);

const uid = (prefix) => `${prefix}${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;

export function LibraryProvider({ children }) {
  // Steps 1 and 2 of the data flow: read from local storage, use as state.
  const [books, setBooks] = useLocalStorage('lms.books', seedBooks);
  const [users, setUsers] = useLocalStorage('lms.users', seedUsers);
  const [transactions, setTransactions] = useLocalStorage('lms.transactions', seedTransactions);
  const [currentUserId, setCurrentUserId] = useLocalStorage('lms.currentUserId', null);

  const currentUser = useMemo(() => users.find((u) => u.id === currentUserId) || null, [users, currentUserId]);

  /* ---------- Books ---------- */
  const addBook = (values) => {
    const errors = validateBook(values, books);
    if (Object.keys(errors).length) return { ok: false, errors };
    const book = {
      id: uid('b'),
      title: values.title.trim(),
      author: values.author.trim(),
      genre: values.genre.trim(),
      isbn: normaliseIsbn(values.isbn),
      quantity: Number(values.quantity),
    };
    setBooks((prev) => [...prev, book]);
    return { ok: true };
  };

  const updateBook = (id, values) => {
    const errors = validateBook(values, books, id);
    if (Object.keys(errors).length) return { ok: false, errors };
    setBooks((prev) =>
      prev.map((b) =>
        b.id === id
          ? {
              ...b,
              title: values.title.trim(),
              author: values.author.trim(),
              genre: values.genre.trim(),
              isbn: normaliseIsbn(values.isbn),
              quantity: Number(values.quantity),
            }
          : b
      )
    );
    return { ok: true };
  };

  const deleteBook = (id) => setBooks((prev) => prev.filter((b) => b.id !== id));

  /* ---------- Stock transactions ---------- */
  const changeStock = ({ bookId, type, quantity, note }) => {
    const result = applyStockChange(books, transactions, {
      bookId,
      type,
      quantity,
      note,
      performedBy: currentUser ? currentUser.name : '',
    });
    if (result.ok) {
      setBooks(result.books);
      setTransactions(result.transactions);
    }
    return result;
  };

  /* ---------- Users ---------- */
  const addUser = (values) => {
    const errors = validateUser(values, users);
    if (Object.keys(errors).length) return { ok: false, errors };
    setUsers((prev) => [
      ...prev,
      { id: uid('u'), name: values.name.trim(), membershipId: values.membershipId.trim(), role: values.role },
    ]);
    return { ok: true };
  };

  const updateUser = (id, values) => {
    const errors = validateUser(values, users, id);
    const target = users.find((u) => u.id === id);
    const admins = users.filter((u) => u.role === 'admin');
    if (target && target.role === 'admin' && values.role !== 'admin' && admins.length === 1) {
      errors.role = 'There must be at least one administrator.';
    }
    if (Object.keys(errors).length) return { ok: false, errors };
    setUsers((prev) =>
      prev.map((u) =>
        u.id === id ? { ...u, name: values.name.trim(), membershipId: values.membershipId.trim(), role: values.role } : u
      )
    );
    return { ok: true };
  };

  const deleteUser = (id) => {
    const target = users.find((u) => u.id === id);
    if (!target) return { ok: false, error: 'User not found.' };
    if (id === currentUserId) return { ok: false, error: 'You cannot delete the account you are signed in with.' };
    if (target.role === 'admin' && users.filter((u) => u.role === 'admin').length === 1) {
      return { ok: false, error: 'You cannot delete the only administrator.' };
    }
    setUsers((prev) => prev.filter((u) => u.id !== id));
    return { ok: true };
  };

  /* ---------- Login (demo only: not secure authentication) ---------- */
  const login = (name, membershipId) => {
    const user = users.find(
      (u) =>
        u.membershipId.toLowerCase() === membershipId.trim().toLowerCase() &&
        u.name.trim().toLowerCase() === name.trim().toLowerCase()
    );
    if (!user) return { ok: false, error: 'No user matches that name and membership ID.' };
    setCurrentUserId(user.id);
    return { ok: true, user };
  };

  const logout = () => setCurrentUserId(null);

  const resetDemoData = () => {
    setBooks(seedBooks);
    setUsers(seedUsers);
    setTransactions(seedTransactions);
    setCurrentUserId(null);
  };

  const value = {
    books,
    users,
    transactions,
    currentUser,
    addBook,
    updateBook,
    deleteBook,
    changeStock,
    addUser,
    updateUser,
    deleteUser,
    login,
    logout,
    resetDemoData,
  };

  return <LibraryContext.Provider value={value}>{children}</LibraryContext.Provider>;
}

export function useLibrary() {
  const ctx = useContext(LibraryContext);
  if (!ctx) throw new Error('useLibrary must be used inside <LibraryProvider>');
  return ctx;
}
