import { useId } from 'react';

/** Label + input/select wrapper with accessible error messaging. */
export default function Field({ label, error, children }) {
  const id = useId();
  const errorId = `${id}-error`;
  return (
    <div className={`field${error ? ' has-error' : ''}`}>
      <label htmlFor={id}>{label}</label>
      {children({ id, 'aria-invalid': error ? 'true' : 'false', 'aria-describedby': error ? errorId : undefined })}
      {error && (
        <p id={errorId} className="error-text" role="alert">
          {error}
        </p>
      )}
    </div>
  );
}
