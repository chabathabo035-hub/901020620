import { useState, useEffect } from 'react';
import Field from './Field.jsx';

const EMPTY = { title: '', author: '', genre: '', isbn: '', quantity: '1' };

/**
 * Controlled form used for both adding and editing a book.
 * `onSubmit(values)` must return { ok, errors }.
 */
export default function BookForm({ initial, onSubmit, onCancel }) {
  const editing = Boolean(initial);
  const [values, setValues] = useState(EMPTY);
  const [errors, setErrors] = useState({});
  const [saved, setSaved] = useState('');

  // Load the record being edited (or reset) whenever the target changes.
  useEffect(() => {
    setValues(initial ? { ...initial, quantity: String(initial.quantity) } : EMPTY);
    setErrors({});
    setSaved('');
  }, [initial]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setValues((v) => ({ ...v, [name]: value }));
    setSaved('');
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const result = onSubmit(values);
    if (!result.ok) {
      setErrors(result.errors);
      return;
    }
    setErrors({});
    if (editing) {
      onCancel();
    } else {
      setValues(EMPTY);
      setSaved('Book added to the catalogue.');
    }
  };

  return (
    <form className="card form" onSubmit={handleSubmit} noValidate aria-label={editing ? 'Edit book' : 'Add book'}>
      <h2>{editing ? 'Edit book' : 'Add a book'}</h2>
      <div className="grid-2">
        <Field label="Title" error={errors.title}>
          {(p) => <input {...p} name="title" value={values.title} onChange={handleChange} />}
        </Field>
        <Field label="Author" error={errors.author}>
          {(p) => <input {...p} name="author" value={values.author} onChange={handleChange} />}
        </Field>
        <Field label="Genre" error={errors.genre}>
          {(p) => <input {...p} name="genre" value={values.genre} onChange={handleChange} />}
        </Field>
        <Field label="ISBN" error={errors.isbn}>
          {(p) => (
            <input {...p} name="isbn" value={values.isbn} onChange={handleChange} placeholder="978-0-13-235088-4" />
          )}
        </Field>
        <Field label={editing ? 'Quantity in stock' : 'Initial quantity'} error={errors.quantity}>
          {(p) => <input {...p} name="quantity" type="number" min="0" step="1" value={values.quantity} onChange={handleChange} />}
        </Field>
      </div>
      <div className="form-actions">
        <button type="submit" className="btn btn-primary">{editing ? 'Save changes' : 'Add book'}</button>
        {editing && (
          <button type="button" className="btn" onClick={onCancel}>Cancel</button>
        )}
        {saved && <span className="success-text" role="status">{saved}</span>}
      </div>
    </form>
  );
}
