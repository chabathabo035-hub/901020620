import { useState, useEffect } from 'react';
import Field from './Field.jsx';
import { ROLES } from '../utils/validation.js';

const EMPTY = { name: '', membershipId: '', role: 'member' };

/** Controlled form for adding or editing a user. `onSubmit(values)` returns { ok, errors }. */
export default function UserForm({ initial, onSubmit, onCancel }) {
  const editing = Boolean(initial);
  const [values, setValues] = useState(EMPTY);
  const [errors, setErrors] = useState({});
  const [saved, setSaved] = useState('');

  useEffect(() => {
    setValues(initial ? { name: initial.name, membershipId: initial.membershipId, role: initial.role } : EMPTY);
    setErrors({});
    setSaved('');
  }, [initial]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setValues((v) => ({ ...v, [name]: value }));
    setSaved('');
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const result = onSubmit(values);
    if (!result.ok) {
      setErrors(result.errors);
      return;
    }
    setErrors({});
    if (editing) onCancel();
    else {
      setValues(EMPTY);
      setSaved('User added.');
    }
  };

  return (
    <form className="card form" onSubmit={handleSubmit} noValidate aria-label={editing ? 'Edit user' : 'Add user'}>
      <h2>{editing ? 'Edit user' : 'Add a user'}</h2>
      <div className="grid-3">
        <Field label="Name" error={errors.name}>
          {(p) => <input {...p} name="name" value={values.name} onChange={handleChange} />}
        </Field>
        <Field label="Membership ID" error={errors.membershipId}>
          {(p) => <input {...p} name="membershipId" value={values.membershipId} onChange={handleChange} placeholder="M-0004" />}
        </Field>
        <Field label="Role" error={errors.role}>
          {(p) => (
            <select {...p} name="role" value={values.role} onChange={handleChange}>
              {ROLES.map((r) => (
                <option key={r} value={r}>{r}</option>
              ))}
            </select>
          )}
        </Field>
      </div>
      <div className="form-actions">
        <button type="submit" className="btn btn-primary">{editing ? 'Save changes' : 'Add user'}</button>
        {editing && <button type="button" className="btn" onClick={onCancel}>Cancel</button>}
        {saved && <span className="success-text" role="status">{saved}</span>}
      </div>
    </form>
  );
}
