import { useState } from 'react';
import Field from './Field.jsx';

/** Controlled form for adding or deducting stock. `onSubmit(values)` returns { ok, errors }. */
export default function TransactionForm({ books, onSubmit }) {
  const [values, setValues] = useState({ bookId: '', type: 'deduct', quantity: '1', note: '' });
  const [errors, setErrors] = useState({});
  const [message, setMessage] = useState('');

  const selected = books.find((b) => b.id === values.bookId);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setValues((v) => ({ ...v, [name]: value }));
    setMessage('');
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const result = onSubmit(values);
    if (!result.ok) {
      setErrors(result.errors);
      setMessage('');
      return;
    }
    setErrors({});
    const verb = values.type === 'add' ? 'added to' : 'borrowed from';
    setMessage(`${values.quantity} cop${Number(values.quantity) === 1 ? 'y' : 'ies'} ${verb} “${selected.title}”.`);
    setValues((v) => ({ ...v, quantity: '1', note: '' }));
  };

  return (
    <form className="card form" onSubmit={handleSubmit} noValidate aria-label="Record stock change">
      <h2>Record a stock change</h2>
      <div className="grid-2">
        <Field label="Book" error={errors.bookId}>
          {(p) => (
            <select {...p} name="bookId" value={values.bookId} onChange={handleChange}>
              <option value="">Select a book…</option>
              {books.map((b) => (
                <option key={b.id} value={b.id}>
                  {b.title} ({b.quantity} in stock)
                </option>
              ))}
            </select>
          )}
        </Field>
        <Field label="Quantity" error={errors.quantity}>
          {(p) => <input {...p} name="quantity" type="number" min="1" step="1" value={values.quantity} onChange={handleChange} />}
        </Field>
      </div>

      <fieldset className="type-picker">
        <legend>Transaction type</legend>
        <label className={`choice${values.type === 'deduct' ? ' active' : ''}`}>
          <input type="radio" name="type" value="deduct" checked={values.type === 'deduct'} onChange={handleChange} />
          Stock deduction <span className="muted small">(book borrowed)</span>
        </label>
        <label className={`choice${values.type === 'add' ? ' active' : ''}`}>
          <input type="radio" name="type" value="add" checked={values.type === 'add'} onChange={handleChange} />
          Stock addition <span className="muted small">(copies arrived)</span>
        </label>
      </fieldset>

      <Field label="Note (optional)">
        {(p) => <input {...p} name="note" value={values.note} onChange={handleChange} placeholder="e.g. Borrowed by M-0003" />}
      </Field>

      {selected && (
        <p className="muted small">
          Selected: <strong>{selected.title}</strong> — currently {selected.quantity} in stock.
        </p>
      )}

      <div className="form-actions">
        <button type="submit" className="btn btn-primary">
          {values.type === 'add' ? 'Add stock' : 'Deduct stock'}
        </button>
        {message && <span className="success-text" role="status">{message}</span>}
      </div>
    </form>
  );
}
