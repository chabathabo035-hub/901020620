import { useState } from 'react';
import Field from './Field.jsx';

/** Demo login: matches a stored user by name + membership ID. Not real authentication. */
export default function LoginForm({ onLogin }) {
  const [values, setValues] = useState({ name: '', membershipId: '' });
  const [error, setError] = useState('');

  const handleChange = (e) => {
    const { name, value } = e.target;
    setValues((v) => ({ ...v, [name]: value }));
    setError('');
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!values.name.trim() || !values.membershipId.trim()) {
      setError('Enter both your name and membership ID.');
      return;
    }
    const result = onLogin(values.name, values.membershipId);
    if (!result.ok) setError(result.error);
  };

  const fill = (name, membershipId) => {
    setValues({ name, membershipId });
    setError('');
  };

  return (
    <form className="card form login" onSubmit={handleSubmit} noValidate aria-label="Login">
      <h1>Sign in</h1>
      <Field label="Name">
        {(p) => <input {...p} name="name" autoComplete="name" value={values.name} onChange={handleChange} />}
      </Field>
      <Field label="Membership ID">
        {(p) => <input {...p} name="membershipId" autoComplete="off" value={values.membershipId} onChange={handleChange} />}
      </Field>
      {error && <p className="error-text" role="alert">{error}</p>}
      <button type="submit" className="btn btn-primary btn-block">Log in</button>

      <div className="demo-box">
        <strong>Demo accounts</strong>
        <p className="muted small">Click one to fill the form, then press Log in.</p>
        <div className="demo-buttons">
          <button type="button" className="btn btn-sm" onClick={() => fill('Admin User', 'M-0001')}>Admin</button>
          <button type="button" className="btn btn-sm" onClick={() => fill('Lerato Librarian', 'M-0002')}>Librarian</button>
          <button type="button" className="btn btn-sm" onClick={() => fill('Thabo Member', 'M-0003')}>Member</button>
        </div>
      </div>
      <p className="muted small">
        This login only demonstrates interface behaviour. Real systems need server-side authentication and access control.
      </p>
    </form>
  );
}
