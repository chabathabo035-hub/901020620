import { Link } from 'react-router-dom';
import { useLibrary } from '../context/LibraryContext.jsx';

/** Shows children only to signed-in users with an allowed role. */
export default function RequireRole({ roles, children }) {
  const { currentUser } = useLibrary();

  if (!currentUser) {
    return (
      <section className="card notice">
        <h1>Please sign in</h1>
        <p>You need to log in as a librarian or administrator to use this page.</p>
        <Link className="btn btn-primary" to="/users">Go to login</Link>
      </section>
    );
  }
  if (!roles.includes(currentUser.role)) {
    return (
      <section className="card notice">
        <h1>Access restricted</h1>
        <p>
          Your role (<strong>{currentUser.role}</strong>) cannot open this page. Ask an administrator for access.
        </p>
        <Link className="btn" to="/">Back to dashboard</Link>
      </section>
    );
  }
  return children;
}
