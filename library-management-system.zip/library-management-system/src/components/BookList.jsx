import { isLowStock } from '../utils/validation.js';

/** Table of books. If onEdit/onDelete are passed, action buttons are shown. */
export default function BookList({ books, onEdit, onDelete, emptyText = 'No books found.' }) {
  const hasActions = Boolean(onEdit || onDelete);

  if (books.length === 0) return <p className="empty">{emptyText}</p>;

  return (
    <div className="table-wrap">
      <table>
        <thead>
          <tr>
            <th>Title</th>
            <th>Author</th>
            <th>Genre</th>
            <th>ISBN</th>
            <th className="num">In stock</th>
            {hasActions && <th>Actions</th>}
          </tr>
        </thead>
        <tbody>
          {books.map((b) => {
            const low = isLowStock(b);
            return (
              <tr key={b.id} className={low ? 'low-stock' : ''}>
                <td data-label="Title"><strong>{b.title}</strong></td>
                <td data-label="Author">{b.author}</td>
                <td data-label="Genre">{b.genre}</td>
                <td data-label="ISBN" className="mono">{b.isbn}</td>
                <td data-label="In stock" className="num">
                  {b.quantity}{' '}
                  {low && (
                    <span className="badge badge-warn">{b.quantity === 0 ? 'Out of stock' : 'Low stock'}</span>
                  )}
                </td>
                {hasActions && (
                  <td data-label="Actions" className="actions">
                    {onEdit && (
                      <button className="btn btn-sm" onClick={() => onEdit(b)} aria-label={`Edit ${b.title}`}>Edit</button>
                    )}
                    {onDelete && (
                      <button className="btn btn-sm btn-danger" onClick={() => onDelete(b)} aria-label={`Delete ${b.title}`}>Delete</button>
                    )}
                  </td>
                )}
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
