import { NavLink, useNavigate } from 'react-router-dom';
import { useLibrary } from '../context/LibraryContext.jsx';

export default function Navbar() {
  const { currentUser, logout } = useLibrary();
  const navigate = useNavigate();
  const canManage = currentUser && ['admin', 'librarian'].includes(currentUser.role);

  const handleLogout = () => {
    logout();
    navigate('/users');
  };

  return (
    <header className="navbar">
      <div className="navbar-inner">
        <NavLink to="/" className="brand" aria-label="Library Management System home">
          <span aria-hidden="true">📚</span> LibraryMS
        </NavLink>
        <nav aria-label="Main navigation" className="nav-links">
          <NavLink to="/" end>Dashboard</NavLink>
          {canManage && <NavLink to="/books">Books</NavLink>}
          {canManage && <NavLink to="/transactions">Transactions</NavLink>}
          <NavLink to="/users">{currentUser ? 'Users' : 'Login'}</NavLink>
        </nav>
        <div className="nav-user">
          {currentUser ? (
            <>
              <span className="user-chip" title={`Membership ID ${currentUser.membershipId}`}>
                {currentUser.name} <span className={`badge role-${currentUser.role}`}>{currentUser.role}</span>
              </span>
              <button className="btn btn-ghost btn-sm" onClick={handleLogout}>Log out</button>
            </>
          ) : (
            <span className="muted small">Not signed in</span>
          )}
        </div>
      </div>
    </header>
  );
}
