import test from 'node:test';
import assert from 'node:assert/strict';
import { validateBook, validateUser, validateStockChange, isLowStock, isValidIsbn } from '../src/utils/validation.js';
import { applyStockChange } from '../src/utils/stock.js';
import { seedBooks } from '../src/utils/seed.js';

const goodBook = { title: 'T', author: 'A', genre: 'G', isbn: '978-0-306-40615-7', quantity: '3' };

test('valid book passes validation', () => {
  assert.deepEqual(validateBook(goodBook, seedBooks), {});
});

test('required fields and quantity are validated', () => {
  const errs = validateBook({ title: '', author: '', genre: '', isbn: '', quantity: '-1' }, []);
  assert.ok(errs.title && errs.author && errs.genre && errs.isbn && errs.quantity);
});

test('ISBN format and duplicates', () => {
  assert.equal(isValidIsbn('123'), false);
  assert.equal(isValidIsbn('0-306-40615-2'), true);
  const errs = validateBook({ ...goodBook, isbn: seedBooks[0].isbn }, seedBooks);
  assert.match(errs.isbn, /already uses/);
  // editing the same book with its own ISBN is fine
  assert.deepEqual(validateBook({ ...goodBook, isbn: seedBooks[0].isbn }, seedBooks, seedBooks[0].id), {});
});

test('user validation catches duplicate membership IDs', () => {
  const users = [{ id: 'u1', name: 'A', membershipId: 'M-1', role: 'admin' }];
  assert.ok(validateUser({ name: 'B', membershipId: 'm-1', role: 'member' }, users).membershipId);
  assert.deepEqual(validateUser({ name: 'B', membershipId: 'M-2', role: 'member' }, users), {});
});

test('low stock means fewer than two copies', () => {
  assert.equal(isLowStock({ quantity: 1 }), true);
  assert.equal(isLowStock({ quantity: 0 }), true);
  assert.equal(isLowStock({ quantity: 2 }), false);
});

test('deducting more than available is rejected and nothing changes', () => {
  const book = seedBooks[1]; // quantity 1
  assert.ok(validateStockChange(book, 'deduct', '2').quantity);
  const res = applyStockChange(seedBooks, [], { bookId: book.id, type: 'deduct', quantity: '2' });
  assert.equal(res.ok, false);
  assert.equal(res.books, seedBooks);
  assert.equal(res.transactions.length, 0);
});

test('cannot borrow when out of stock', () => {
  const res = applyStockChange(seedBooks, [], { bookId: 'b4', type: 'deduct', quantity: '1' });
  assert.equal(res.ok, false);
  assert.match(res.errors.quantity, /No copies/);
});

test('stock changes update quantity and history together', () => {
  let books = seedBooks;
  let txs = [];
  let r = applyStockChange(books, txs, { bookId: 'b1', type: 'deduct', quantity: '2', performedBy: 'Lerato' });
  assert.ok(r.ok);
  assert.equal(r.books.find((b) => b.id === 'b1').quantity, 3);
  assert.equal(r.transactions[0].balanceAfter, 3);
  ({ books, transactions: txs } = r);

  r = applyStockChange(books, txs, { bookId: 'b1', type: 'add', quantity: '4' });
  assert.equal(r.books.find((b) => b.id === 'b1').quantity, 7);
  assert.equal(r.transactions.length, 2);
  assert.equal(r.transactions[0].type, 'add'); // newest first
  // other books untouched
  assert.equal(r.books.find((b) => b.id === 'b2').quantity, 1);
});

test('invalid quantities are rejected', () => {
  for (const q of ['0', '-1', '1.5', 'abc', '']) {
    assert.ok(validateStockChange(seedBooks[0], 'add', q).quantity, `quantity ${q}`);
  }
});
