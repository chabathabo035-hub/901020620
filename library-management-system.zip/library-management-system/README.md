# Library Management System (React)

A React single-page application for managing a library catalogue, stock, transactions and users.
All data is stored in the browser's **local storage** (no server or database).

## Quick start

### Option A: just open it (no install)
Double-click **`library-management-system.html`**. It is a self-contained build and works offline.

### Option B: run the full React project
Requires [Node.js](https://nodejs.org) 18 or newer.

```bash
npm install
npm run dev        # development server (http://localhost:5173)
npm run build      # production build into dist/ (single index.html, also opens from disk)
npm test           # unit tests for validation and stock logic
```

## Demo accounts (Users / Login page)

| Role      | Name             | Membership ID |
|-----------|------------------|---------------|
| Admin     | Admin User       | M-0001        |
| Librarian | Lerato Librarian | M-0002        |
| Member    | Thabo Member     | M-0003        |

On the login page, click a demo button to fill the form, then press **Log in**.

## Features (mapped to the study notes)

- **Dashboard**: availability overview, search, "low stock only" filter. Books with **fewer than two copies** are highlighted.
- **Book management**: add, edit and delete books (title, author, genre, ISBN, quantity). Validation for required fields, ISBN format, duplicate ISBNs and quantity.
- **Transactions**: stock addition and stock deduction. A deduction is refused if it would make stock negative. Each change updates the book quantity and writes a history entry together. Filterable history log.
- **User management and login**: add/update/delete users (name, membership ID, role); login form. Protected pages by role. Cannot delete yourself or the only admin.
- **React concepts**: components and composition, `useState`, `useEffect` (load/save local storage), controlled forms, React Router (`HashRouter`), context for shared state.
- **Responsive CSS**: tables turn into stacked cards on phones; accessible labels, errors and keyboard focus.

## Project structure

```
src/
  main.jsx                 entry, router + provider
  App.jsx                  routes
  context/LibraryContext   shared state + local-storage persistence
  pages/                   Dashboard, BooksPage, TransactionsPage, UsersPage
  components/              Navbar, BookForm, BookList, TransactionForm,
                           UserForm, LoginForm, Field, RequireRole
  utils/                   validation, stock logic, useLocalStorage hook, seed data
tests/logic.test.js        unit tests (node --test)
```

## Data and security notes

- Data lives only in this browser/device. Clearing site data removes it. Use **Users → Reset demo data** (admin) to restore the samples.
- The login is a client-side demo of interface behaviour. It is **not** secure authentication; a real system needs a server, hashed passwords and server-side access control.
